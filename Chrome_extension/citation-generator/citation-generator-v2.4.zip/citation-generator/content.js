// Wikipedia Citation Generator - by Suyash Dwivedi
// v2.4: Two new features:
//   (1) Search-engine results page guard: blocks Google/Bing/DDG/Yahoo/Brave/
//       Ecosia/Yandex results pages with a clear alert (Google Books excluded).
//   (2) Google Books citer-fallback rescue: when the Books API returns nothing
//       (common for old scans) and citer gives back "title=Google Books |
//       website=Google", we decode the real title from the /edition/ URL path
//       and rebuild a proper {{cite book}} — no extra API calls needed.

let button = null;
let isGenerating = false;

// ── Pre-load audio ONCE at startup ────────────────────────────────────────────
const audio = new Audio('https://suyashdwivedi.github.io/alert.mp3');
audio.volume = 0.5;
audio.preload = 'auto';

// ── Citation cache ────────────────────────────────────────────────────────────
const memCache = new Map();

async function getCached(url) {
  if (memCache.has(url)) return memCache.get(url);
  return new Promise(resolve => {
    chrome.storage.local.get(url, result => resolve(result[url] || null));
  });
}

async function setCache(url, citation) {
  memCache.set(url, citation);
  chrome.storage.local.get(null, items => {
    const keys = Object.keys(items);
    if (keys.length >= 200) chrome.storage.local.remove(keys[0]);
    chrome.storage.local.set({ [url]: citation });
  });
}

// ── Button ────────────────────────────────────────────────────────────────────
function createButton() {
  if (button) return;
  button = document.createElement('button');
  button.id = 'wiki-cite-btn';
  button.innerHTML = '📝';
  button.title = 'Generate Wikipedia Citation - by Suyash Dwivedi';
  document.body.appendChild(button);
  button.addEventListener('click', generateCitation);
}

// ── Fetch with timeout ────────────────────────────────────────────────────────
async function fetchWithTimeout(url, ms = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    return res;
  } catch (err) {
    clearTimeout(timer);
    throw err;
  }
}

// ── Extract {{cite web}} from citer HTML ──────────────────────────────────────
function extractCitation(html) {
  for (const line of html.split('\n')) {
    if (line.includes('{{cite web')) return line.trim();
  }
  const doc = new DOMParser().parseFromString(html, 'text/html');
  for (const el of doc.querySelectorAll('textarea, pre, code, div')) {
    const c = el.value || el.textContent;
    if (c && c.includes('{{cite web')) return c.trim();
  }
  return null;
}

// ── Clean up raw citer output ─────────────────────────────────────────────────
function cleanCiterCitation(raw) {
  let citation = raw;
  for (const line of raw.split('\n')) {
    if (line.includes('{{cite')) { citation = line.trim(); break; }
  }
  return citation.replace(/^\*\s*/, '').trim();
}

// ── Date formatter ────────────────────────────────────────────────────────────
const MONTHS = ['January','February','March','April','May','June',
                'July','August','September','October','November','December'];

function formatDates(citation) {
  return citation.replace(
    /(date|access-date)=(\d{4})-(\d{2})-(\d{2})/g,
    (_, key, y, mo, d) => `${key}=${parseInt(d)} ${MONTHS[parseInt(mo) - 1]} ${y}`
  );
}

// ── [NEW] Search-engine results-page detection ────────────────────────────────
// Returns true only when the user is on a search RESULTS page.
// google.*/books is intentionally excluded — it is a real, citable source.
function isSearchResultsPage(url) {
  try {
    const u    = new URL(url);
    const host = u.hostname.replace(/^www\./, '');

    // Google: has ?q= param but is NOT on the /books path
    if (/^google\.[a-z.]+$/.test(host))
      return u.searchParams.has('q') && !u.pathname.startsWith('/books');

    if (host === 'bing.com')
      return u.pathname.startsWith('/search');

    if (host === 'duckduckgo.com')
      return u.searchParams.has('q');

    if (host === 'search.yahoo.com')
      return true;

    if (host === 'search.brave.com')
      return u.pathname.startsWith('/search');

    if (host === 'ecosia.org')
      return u.pathname.startsWith('/search');

    if (host === 'yandex.com' || host === 'yandex.ru')
      return u.pathname.startsWith('/search');

    return false;
  } catch { return false; }
}

// ── Google Books helpers ──────────────────────────────────────────────────────
function isGoogleBooksUrl(url) {
  return /\bgoogle\.[a-z.]+\/books\b/.test(url) || url.includes('books.google.');
}

function getGoogleBooksVolumeId(url) {
  try {
    const u = new URL(url);
    const id = u.searchParams.get('id');
    if (id) return id;
    const m = u.pathname.match(/\/books\/edition\/[^/]+\/([A-Za-z0-9_-]+)/);
    if (m) return m[1];
  } catch { /* fall through */ }
  return null;
}

function getPageFromUrl(url) {
  try {
    const pg = new URL(url).searchParams.get('pg');
    if (!pg) return null;
    const m = pg.match(/[A-Z]+(\d+)/);
    return m ? m[1] : null;
  } catch { return null; }
}

// ── [NEW] Decode real book title from Google Books /edition/ URL ──────────────
// Example: /books/edition/Sa%E1%B9%83skr%CC%A5ti_sandh%C4%81na/_3ZQAQAAMAAJ
//       => "Saṃskṛti Sandhāna"
// This works even for pre-1923 scans that the Books API returns no metadata for.
function titleFromGoogleBooksPath(url) {
  try {
    const m = new URL(url).pathname.match(/\/books\/edition\/([^/]+)\//);
    if (!m) return null;
    return decodeURIComponent(m[1]).replace(/_/g, ' ').trim();
  } catch { return null; }
}

// ── [NEW] Rescue a useless citer stub into a proper {{cite book}} ─────────────
// Called only when citer returned title=Google Books / website=Google.
function patchGoogleBooksCiteWeb(citation, pageUrl) {
  if (!citation.includes('{{cite web')) return citation;

  // Priority: title from URL path > title from document.title
  const urlTitle = titleFromGoogleBooksPath(pageUrl);
  const docTitle = document.title
    .replace(/\s*[-–—|]\s*Google Books\s*$/i, '').trim();
  const bestTitle = (urlTitle && urlTitle.length > 3) ? urlTitle
                  : (docTitle && docTitle.length > 3) ? docTitle
                  : null;

  if (!bestTitle) return citation;   // nothing we can improve

  let cite = citation
    .replace('{{cite web', '{{cite book')
    // Replace the wrong title
    .replace(/\|\s*title\s*=\s*Google Books\s*/gi, ` | title=${bestTitle} `)
    // Remove "website=Google" — invalid in {{cite book}}
    .replace(/\|\s*website\s*=\s*Google\s*/gi, ' ')
    // Remove the crawl/index date — it is NOT the publication date
    .replace(/\|\s*date\s*=[^|}\n]*/g, '')
    // Tidy up artifacts
    .replace(/\|\s*\|/g, '|')
    .replace(/\s{2,}/g, ' ')
    .trim();

  // Record where the book was accessed
  if (!cite.includes('via='))
    cite = cite.replace('}}', ' | via=Google Books}}');

  return cite;
}

// ── Open Library author fallback ──────────────────────────────────────────────
async function fetchOpenLibraryAuthors(title, isbn) {
  try {
    const query = isbn
      ? `isbn=${encodeURIComponent(isbn)}`
      : `title=${encodeURIComponent(title.slice(0, 60))}&limit=1`;
    const res = await fetchWithTimeout(
      `https://openlibrary.org/search.json?${query}&fields=author_name`, 6000
    );
    if (!res.ok) return [];
    const data = await res.json();
    return data.docs?.[0]?.author_name || [];
  } catch { return []; }
}

function formatAuthors(authors) {
  if (!authors || authors.length === 0) return '';
  const list = authors.length > 4 ? [...authors.slice(0, 4), 'et al.'] : [...authors];
  const [first, ...rest] = list;
  const parts = first.trim().split(/\s+/);
  const lastName = parts.pop();
  const firstName = parts.join(' ');
  let part = firstName
    ? ` | last=${lastName} | first=${firstName}`
    : ` | author=${lastName}`;
  rest.forEach((a, i) => { part += ` | author${i + 2}=${a}`; });
  return part;
}

// ── Build {{cite book}} via Google Books API ──────────────────────────────────
async function buildCiteBook(pageUrl) {
  const volumeId = getGoogleBooksVolumeId(pageUrl);
  if (!volumeId) return null;

  let data;
  try {
    const res = await fetchWithTimeout(
      `https://www.googleapis.com/books/v1/volumes/${volumeId}`, 8000
    );
    if (!res.ok) return null;
    data = await res.json();
  } catch { return null; }

  const info = data.volumeInfo || {};
  if (!info.title) return null;

  const today      = new Date();
  const accessDate = `${today.getDate()} ${MONTHS[today.getMonth()]} ${today.getFullYear()}`;
  const title      = info.title;
  const subtitle   = info.subtitle ? ': ' + info.subtitle : '';
  const publisher  = info.publisher || '';
  const year       = info.publishedDate ? info.publishedDate.slice(0, 4) : '';
  const isbn       = (info.industryIdentifiers || [])
                       .find(x => x.type === 'ISBN_13' || x.type === 'ISBN_10');
  const isbnStr    = isbn ? ` | isbn=${isbn.identifier}` : '';
  const page       = getPageFromUrl(pageUrl);
  const pageStr    = page ? ` | page=${page}` : '';

  let authors = info.authors || [];
  if (authors.length === 0)
    authors = await fetchOpenLibraryAuthors(title, isbn?.identifier || '');
  const authorPart = formatAuthors(authors);

  return `{{cite book${authorPart} | title=${title}${subtitle}` +
         ` | publisher=${publisher} | year=${year}${isbnStr}${pageStr}` +
         ` | url=${pageUrl} | access-date=${accessDate}}}`;
}

// ── Tab picker ────────────────────────────────────────────────────────────────
function escapeHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function showTabPicker(editTabs) {
  document.getElementById('wiki-cite-picker')?.remove();
  const picker = document.createElement('div');
  picker.id = 'wiki-cite-picker';
  picker.innerHTML = `
    <div class="wcp-header">
      <span>📋 Which Wikipedia tab?</span>
      <button class="wcp-close">✕</button>
    </div>
    <div class="wcp-hint">Summary will be filled in that tab's language:</div>
    <ul class="wcp-list">
      ${editTabs.map((tab, i) => `
        <li>
          <button class="wcp-tab-btn" data-index="${i}">
            <span class="wcp-lang">${escapeHtml(tab.lang)}</span>
            <span class="wcp-info">
              <span class="wcp-title">${escapeHtml(tab.title.replace(/ - Edit source.*| - Wikipedia.*/i,'').trim())}</span>
              <span class="wcp-summary">"${escapeHtml(tab.summary)}"</span>
            </span>
            <span class="wcp-arrow">→</span>
          </button>
        </li>`).join('')}
    </ul>`;
  document.body.appendChild(picker);
  picker.querySelector('.wcp-close').addEventListener('click', () => picker.remove());
  picker.querySelectorAll('.wcp-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = editTabs[+btn.dataset.index];
      chrome.runtime.sendMessage({ action: 'fillSummaryInTab', tabId: tab.id });
      btn.querySelector('.wcp-arrow').textContent = '✓';
      btn.disabled = true;
      setTimeout(() => picker.remove(), 1000);
    });
  });
  setTimeout(() => picker.remove(), 30000);
}

// ── Edit summary ──────────────────────────────────────────────────────────────
function handleEditSummary() {
  if (window.location.hostname.includes('wikipedia.org') &&
      window.location.search.includes('action=edit')) {
    chrome.runtime.sendMessage({ action: 'fillSenderTab' });
    return;
  }
  chrome.runtime.sendMessage({ action: 'getEditTabs' }, (res) => {
    if (chrome.runtime.lastError || !res) return;
    const { editTabs } = res;
    if (editTabs.length === 0) return;
    if (editTabs.length === 1) {
      chrome.runtime.sendMessage({ action: 'fillSummaryInTab', tabId: editTabs[0].id });
      return;
    }
    showTabPicker(editTabs);
  });
}

// ── Fetch from citer.toolforge.org ────────────────────────────────────────────
async function fetchFromCiter(pageUrl) {
  const response = await fetchWithTimeout(
    `https://citer.toolforge.org/?user_input=${encodeURIComponent(pageUrl)}`
  );
  const html = await response.text();
  const raw  = extractCitation(html);
  if (!raw) throw new Error('Could not extract citation from citer.');
  let citation = cleanCiterCitation(raw);
  citation = formatDates(citation);

  // [NEW] If citer gave back a useless Google Books stub, rescue it
  if (isGoogleBooksUrl(pageUrl) &&
      (citation.includes('title=Google Books') || citation.includes('website=Google'))) {
    citation = patchGoogleBooksCiteWeb(citation, pageUrl);
  }

  return citation;
}

// ── Main ──────────────────────────────────────────────────────────────────────
async function generateCitation() {
  if (isGenerating) return;
  isGenerating = true;

  const originalText = button.innerHTML;
  button.innerHTML   = '⏳';
  button.disabled    = true;

  try {
    const pageUrl = window.location.href;

    // [NEW] Step 0 — block search-engine results pages
    if (isSearchResultsPage(pageUrl)) {
      button.innerHTML = '✗';
      isGenerating     = false;
      button.disabled  = false;
      setTimeout(() => {
        alert(
          '⚠️ You are on a search results page.\n\n' +
          'Search results cannot be cited — please open the actual book, ' +
          'article, or website you want to cite, then click the button again.'
        );
        button.innerHTML = originalText;
      }, 150);
      return;
    }

    // Step 1 — cache check (bypass stale cite web entries for Google Books)
    let citation = await getCached(pageUrl);
    if (citation && isGoogleBooksUrl(pageUrl) && citation.includes('{{cite web'))
      citation = null;

    if (!citation) {
      if (isGoogleBooksUrl(pageUrl)) {
        // Step 2a — Google Books: API first, patched citer as fallback
        const [citebook] = await Promise.all([
          buildCiteBook(pageUrl),
          new Promise(resolve => chrome.runtime.sendMessage({ action: 'getEditTabs' }, resolve))
        ]);
        citation = citebook || await fetchFromCiter(pageUrl);
      } else {
        // Step 2b — regular page
        const [citerResult] = await Promise.all([
          fetchFromCiter(pageUrl),
          new Promise(resolve => chrome.runtime.sendMessage({ action: 'getEditTabs' }, resolve))
        ]);
        citation = citerResult;
      }
      await setCache(pageUrl, citation);
    }

    const refName      = 'm' + Math.floor(Math.random() * 1000);
    const fullCitation = `<ref name="${refName}">${citation}</ref>`;

    // Step 3 — clipboard + audio together
    await Promise.allSettled([
      navigator.clipboard.writeText(fullCitation),
      audio.play().catch(e => console.log('Sound skipped:', e)),
    ]);

    handleEditSummary();
    button.innerHTML = '✓';

  } catch (err) {
    console.error('Citation error:', err);
    button.innerHTML = '✗';
  } finally {
    setTimeout(() => {
      button.innerHTML = originalText;
      isGenerating     = false;
      button.disabled  = false;
    }, 2000);
  }
}

createButton();
